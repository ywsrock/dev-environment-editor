#!/usr/bin/env bash

set -e

"$(dirname "$0")/npm_install.sh" vim-language-server vim-language-server
