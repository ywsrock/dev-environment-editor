#!/usr/bin/env bash
VERSION="2020.05.09"
curl -L -o clj-kondo-lsp https://github.com/borkdude/clj-kondo/releases/download/v$VERSION/clj-kondo-lsp-server-$VERSION-standalone.jar
