#!/usr/bin/env bash

"$(dirname "$0")/pip_install.sh" fortls fortran-language-server
